from .api import WebAPI

__version__ = "0.8.1"

__all__ = ['WebAPI']
