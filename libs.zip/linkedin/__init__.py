__version__ = '2.0'
VERSION = tuple(map(int, __version__.split('.')))
